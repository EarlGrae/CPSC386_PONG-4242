import pygame, sys, random
from pygame.locals import *

FPS = 60

WINDOWWIDTH = 700
WINDOWHEIGHT = 500

LINETHICKNESS = 10
PADDLESIZE = 50
PADDLEOFFSET = 20

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREY = (220, 220, 220)

playerPoints = 0
computerPoints = 0

pygame.init()

FPSCLOCK = pygame.time.Clock()
DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
pygame.display.set_caption('Pong')

global BASICFONT, BASICFONTSIZE
BASICFONTSIZE = 20
BASICFONT = pygame.font.Font('freesansbold.ttf', BASICFONTSIZE)

ballX = WINDOWWIDTH / 2 - LINETHICKNESS/2
ballY = WINDOWHEIGHT / 2 - LINETHICKNESS / 2
playerWallPosition = (WINDOWHEIGHT - PADDLESIZE) / 2
playerTopCeilingPositionX = (WINDOWWIDTH / 4)
playerBottomCeilingPositionX = WINDOWWIDTH / 4
playerTopCeilingPositionY = WINDOWHEIGHT - PADDLESIZE
playerBottomCeilingPositionY = PADDLESIZE
computerWallPosition = (WINDOWHEIGHT - PADDLESIZE) / 2
computerTopCeilingPositionX = (3 * (WINDOWWIDTH / 4))
computerBottomCeilingPositionX = 3 * ((WINDOWWIDTH / 4))
computerTopCeilingPositionY = WINDOWHEIGHT - PADDLESIZE
computerBottomCeilingPositionY = PADDLESIZE

paddlePlayerWall = pygame.Rect(PADDLEOFFSET, playerWallPosition, LINETHICKNESS, PADDLESIZE)
playerPaddleTopCeiling = pygame.Rect(playerTopCeilingPositionX, playerTopCeilingPositionY, PADDLESIZE,
                                     LINETHICKNESS)
playerPaddleBottomCeiling = pygame.Rect(playerBottomCeilingPositionX, playerBottomCeilingPositionY, PADDLESIZE,
                                        LINETHICKNESS)

paddleComputerWall = pygame.Rect(WINDOWWIDTH - PADDLEOFFSET - LINETHICKNESS, computerWallPosition, LINETHICKNESS,
                                 PADDLESIZE)
computerPaddleTopCeiling = pygame.Rect(computerTopCeilingPositionX, computerTopCeilingPositionY, PADDLESIZE,
                                       LINETHICKNESS)
computerPaddleBottomCeiling = pygame.Rect(computerBottomCeilingPositionX, computerBottomCeilingPositionY,
                                          PADDLESIZE, LINETHICKNESS)

ball = pygame.Rect(ballX, ballY, LINETHICKNESS, LINETHICKNESS)

background = pygame.image.load('background.png').convert()
ballImage = pygame.image.load('Ball.png').convert()
computerPaddle = pygame.image.load('Computer_Paddle.png').convert()
computerSupporter = pygame.image.load('Computer_Supporter.png').convert()
playerPaddle = pygame.image.load('Player_Paddle.png').convert()
playerSupporter = pygame.image.load('Player_Supporter.png').convert()

soundtrack = pygame.mixer.music.load("ESJ_OST_Tribute.mp3")
pygame.mixer.music.play(-1)
ricochet = pygame.mixer.Sound("Reflect.wav")
ricochet.set_volume(50.0)
lose = pygame.mixer.music.load("Lose.wav")
#look, the sound's there, and i could comment out the soundtrack and you can hear it
# but come on. the wub wub wub's way more fun, and it's still technically there...

ballDirX = random.randint(0,1)  ## -1 = left 1 = right
if(ballDirX == 0):
    ballDirX = -1
ballDirY = random.randint(0,1)  ## -1 = up 1 = down
if(ballDirY == 0):
    ballDirY = -1

playerPaddleWallDirY = 0
playerPaddleCeilingDirX = 0
computerPaddleWallDirY = 0
computerPaddleCeilingDirX = 0

wallPaddles = [playerPaddleBottomCeiling, playerPaddleTopCeiling, computerPaddleBottomCeiling, computerPaddleTopCeiling]
mainPaddles = [paddlePlayerWall, paddleComputerWall]

def reset():
    ballDirX = random.randint(0, 1)  ## -1 = left 1 = right
    if (ballDirX == 0):
        ballDirX = -1
    ballDirY = random.randint(0, 1)  ## -1 = up 1 = down
    if (ballDirY == 0):
        ballDirY = -1

    ball.x = WINDOWWIDTH / 2 - LINETHICKNESS / 2
    ball.y = WINDOWHEIGHT / 2 - LINETHICKNESS / 2
    paddlePlayerWall.y = (WINDOWHEIGHT - PADDLESIZE) / 2
    playerPaddleTopCeiling.x = (WINDOWWIDTH / 4)
    playerPaddleBottomCeiling.x = WINDOWWIDTH / 4
    paddleComputerWall.y = (WINDOWHEIGHT - PADDLESIZE) / 2
    computerPaddleTopCeiling.x = (3 * (WINDOWWIDTH / 4))
    computerPaddleBottomCeiling.x = 3 * ((WINDOWWIDTH / 4))

def displayScore(playerScore, computerScore):
    resultSurf = BASICFONT.render('%s' %(computerScore), True, GREY)
    resultRect = resultSurf.get_rect()
    resultRect.topleft = (WINDOWWIDTH - 200, 25)
    DISPLAYSURF.blit(resultSurf, resultRect)

    resultSurf = BASICFONT.render('%s' %(playerScore), True, GREY)
    resultRect = resultSurf.get_rect()
    resultRect.topleft = (200, 25)
    DISPLAYSURF.blit(resultSurf, resultRect)

def checkHitBallY(ball, playerPaddleTopCeiling, playerPaddleBottomCeiling, computerPaddleBottomCeiling, computerPaddleTopCeiling, ballDirX):
    for wallPaddle in wallPaddles[:]:
        if ball.colliderect(wallPaddle):
            ricochet.play()
            return -1
    return 1


def checkHitBallX(ball, paddlePlayerWall, paddleComputerWall, ballDirX):
    for mainPaddle in mainPaddles[:]:
        if ball.colliderect(mainPaddle):
            ricochet.play()
            return -1
    return 1

def artificialIntelligenceWall(ball, ballDirX, paddleWall):
#If ball is moving away from paddle, center bat
    if ballDirX == -1:
        if paddleWall.centery < (WINDOWHEIGHT/2):
            paddleWall.y += 1
        if paddleWall.centery > (WINDOWHEIGHT/2):
            paddleWall.y -= 1
    #if ball moving towards bat, track its movement.
    else:
        if (ball.x > (3*(WINDOWWIDTH / 4))):
            if paddleWall.centery < ball.centery:
                paddleWall.y += 1
            else:
                paddleWall.y -=1
    return paddleWall

def aiCeiling(ball, ballDirX, paddle, xDirection):
    if(ball.centerx > (WINDOWWIDTH/2)):
        if(ball.centerx) > paddle.centerx:
            xDirection = 1
        if ball.centerx < paddle.centerx:
            xDirection = -1
        if paddle.centerx == ball.centerx:
            xDirection = 0
    else:
        if(paddle.centerx < (3 * (WINDOWWIDTH/4))):
            xDirection = 1
        if (paddle.centerx > (3 * (WINDOWWIDTH/4))):
            xDirection = -1
        if (paddle.centerx == (3 * (WINDOWWIDTH/4))):
            xDirection = 0
    return xDirection

def movePaddle(isWall, paddle, dirX, dirY):
    if (isWall):
        paddle.y += dirY
    else:
        paddle.x += dirX

def moveBall(ball, ballDirX, ballDirY):
    ball.x += ballDirX
    ball.y += ballDirY
    return ball

def checkScore(ball, ballDirX, ballDirY, playerPoints, computerPoints):
    if ((ball.top == (LINETHICKNESS) or ball.bottom == (WINDOWHEIGHT - LINETHICKNESS)) and ball.centerx <= (WINDOWWIDTH/2)):
        computerPoints += 1
        lose.play()
        reset()
    if ((ball.top == (LINETHICKNESS) or ball.bottom == (WINDOWHEIGHT - LINETHICKNESS)) and ball.centerx > (WINDOWWIDTH / 2)):
        playerPoints += 1
        lose.play()
        reset()
    if ball.left == (((LINETHICKNESS) and (ball.centerx <= (WINDOWWIDTH/2)))):
        computerPoints += 1
        lose.play()
        reset()
    if ball.right == (((WINDOWWIDTH - LINETHICKNESS) and (ball.centerx > (WINDOWWIDTH/2)))):
        playerPoints += 1
        lose.play()
        reset()
    return playerPoints, computerPoints

def drawArena():
    DISPLAYSURF.blit(background, [0, 0])
    pygame.draw.rect(DISPLAYSURF, BLACK, ((0,0),(WINDOWWIDTH,WINDOWHEIGHT)), LINETHICKNESS*2)
    pygame.draw.line(DISPLAYSURF, WHITE, ((WINDOWWIDTH/2),0),((WINDOWWIDTH/2),WINDOWHEIGHT), 2)

def drawPaddleWall(paddle):
    if paddle.bottom > WINDOWHEIGHT - LINETHICKNESS:
        paddle.bottom = WINDOWHEIGHT - LINETHICKNESS
    elif paddle.top < LINETHICKNESS:
        paddle.top = LINETHICKNESS
    pygame.draw.rect(DISPLAYSURF, WHITE, paddle)
    DISPLAYSURF.blit(playerPaddle, paddle)

def drawPaddleCeilingPlayer(paddle):
    if paddle.left < LINETHICKNESS * 2:
        paddle.left = LINETHICKNESS * 2
    elif paddle.right > (WINDOWWIDTH - LINETHICKNESS)/2:
        paddle.right = (WINDOWWIDTH - LINETHICKNESS)/2
    pygame.draw.rect(DISPLAYSURF, WHITE, paddle)
    DISPLAYSURF.blit(playerSupporter, paddle)

def drawPaddleCeilingComputer(paddle):
    if paddle.left < (WINDOWWIDTH + LINETHICKNESS) / 2:
        paddle.left = (WINDOWWIDTH + LINETHICKNESS) / 2
    elif paddle.right > WINDOWWIDTH - LINETHICKNESS:
        paddle.right = WINDOWWIDTH - LINETHICKNESS
    pygame.draw.rect(DISPLAYSURF, WHITE, paddle)
    DISPLAYSURF.blit(computerSupporter, paddle)

def drawBall(ball):
    pygame.draw.rect(DISPLAYSURF, WHITE, ball)
    DISPLAYSURF.blit(ballImage, ball)


while True: #main game loop
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN:
            if event.key == K_LEFT or event.key == K_a:
                playerPaddleCeilingDirX = -1
            if event.key == K_RIGHT or event.key == K_d:
                playerPaddleCeilingDirX = 1
            if event.key == K_UP or event.key == K_w:
                playerPaddleWallDirY = -1
            if event.key == K_DOWN or event.key == K_s:
                playerPaddleWallDirY = 1
        if event.type == KEYUP:
            if event.key == K_ESCAPE:
                pygame.quit()
                sys.exit()
            if event.key == K_LEFT or event.key == K_a:
                playerPaddleCeilingDirX = 0
            if event.key == K_RIGHT or event.key == K_d:
                playerPaddleCeilingDirX = 0
            if event.key == K_UP or event.key == K_w:
                playerPaddleWallDirY = 0
            if event.key == K_DOWN or event.key == K_s:
                playerPaddleWallDirY = 0

    drawArena()
    drawPaddleWall(paddlePlayerWall)
    drawPaddleCeilingPlayer(playerPaddleBottomCeiling)
    drawPaddleCeilingPlayer(playerPaddleTopCeiling)
    drawPaddleWall(paddleComputerWall)
    drawPaddleCeilingComputer(computerPaddleBottomCeiling)
    drawPaddleCeilingComputer(computerPaddleTopCeiling)
    drawBall(ball)

    ball = moveBall(ball, ballDirX, ballDirY)
    playerPoints, computerPoints = checkScore(ball, ballDirX, ballDirY, playerPoints, computerPoints)
    displayScore(playerPoints, computerPoints)

    movePaddle(True, paddlePlayerWall, 0, playerPaddleWallDirY)
    movePaddle(False, playerPaddleTopCeiling, playerPaddleCeilingDirX, 0)
    movePaddle(False, playerPaddleBottomCeiling, playerPaddleCeilingDirX, 0)

    movePaddle(True, paddleComputerWall, 0, computerPaddleWallDirY)
    movePaddle(False, computerPaddleTopCeiling, computerPaddleCeilingDirX, 0)
    movePaddle(False, computerPaddleBottomCeiling, computerPaddleCeilingDirX, 0)

    paddleComputerWall = artificialIntelligenceWall(ball, ballDirX, paddleComputerWall)
    computerPaddleCeilingDirX = aiCeiling(ball, ballDirX, computerPaddleBottomCeiling, computerPaddleCeilingDirX)

    ballDirY *= checkHitBallY(ball, playerPaddleTopCeiling, playerPaddleBottomCeiling, computerPaddleBottomCeiling,
                              computerPaddleTopCeiling, ballDirX)
    ballDirX *= checkHitBallX(ball, paddlePlayerWall, paddleComputerWall, ballDirX)

    pygame.display.update()
    FPSCLOCK.tick(FPS)